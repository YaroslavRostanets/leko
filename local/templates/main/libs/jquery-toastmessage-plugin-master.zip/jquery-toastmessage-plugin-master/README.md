Do you wanna have some toasts ?
===============================
jquery-toastmessage-plugin is a JQuery plugin which provides android-like notification messages. The toasted messages arriving on the screen in a seamless and natural way. They may or may not disrupt the user and they are still informative. It's a quite nice way to report info or error to the user.

The plugin is entirely customizable. So you can change the positioning, the required user action, the style and so on.

Overview and Demo
=================

To get some more information and see the toastmessage plugin in action, just click [here](http://akquinet.github.com/jquery-toastmessage-plugin).

Documentation
=============
An in depth documentation how to use this plugin can be found at the [Wiki](https://github.com/akquinet/jquery-toastmessage-plugin/wiki).


License
=======
jquery-toastmessage-plugin is licensed under the Apache License 2.0. The project is founded by [akquinet A.G.](http://www.akquinet.de/en)